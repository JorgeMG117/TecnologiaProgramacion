#pragma once

#include <map>

using namespace std;

typedef map<string,float> SymbolTab;
